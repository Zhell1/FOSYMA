package mas.behaviours.atomic;

import mas.abstractAgent;

public class VoidAtomic extends AtomicBehaviour{

	public VoidAtomic(abstractAgent a) {
		/* Désactive l'agent */
		super(a);
		// TODO Auto-generated constructor stub
	}
	
	

}
