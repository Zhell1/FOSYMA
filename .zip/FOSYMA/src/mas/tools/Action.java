package mas.tools;

import mas.agents.GraphAgent;

public interface Action {
	public void act(GraphAgent a);
}
