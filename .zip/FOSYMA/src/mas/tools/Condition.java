package mas.tools;

import mas.agents.GraphAgent;

public interface Condition {
	public boolean check(GraphAgent a);
}
