# FOSYMA

GraphStream Documentation

https://data.graphstream-project.org/api/gs-core/current/

Environment API

https://moodle-sciences.upmc.fr/moodle/pluginfile.php/443883/mod_resource/content/2/Dedale-s1-2018.pdf
